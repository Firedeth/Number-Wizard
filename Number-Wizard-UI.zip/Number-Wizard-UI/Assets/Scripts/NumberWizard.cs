﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class NumberWizard : MonoBehaviour {
	// Use this for initialization
	public int max;
	public int min;
	int guess;
	public int MaxGuessesAllowed = 5;
	
	public Text text;
	
	void Start () {
		StartGame();
		
	}
	
	void StartGame () {
		NextGuess ();
		
	}
	
	public void GuessLower(){
		max = guess;
		NextGuess ();
	}
	
	public void GuessHigher(){
		min = guess;
		NextGuess();
		
	}
	
	void NextGuess () {
		MaxGuessesAllowed -= 1;
		if(MaxGuessesAllowed <= 0){
			Application.LoadLevel("Win");
		}
		guess = Random.Range (min, max+1);
		text.text = guess.ToString();
		max += 1;
	}
}
